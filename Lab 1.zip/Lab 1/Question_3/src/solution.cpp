#include "cllist/solution.h"
#include <iostream>
#include <algorithm>

using namespace std;

namespace cll {

Solution :: ~Solution()
{
    for (CLL* h : heads) {
        free_list(h);
    }
    heads.clear();
}

void Solution::free_list(CLL* head) noexcept
{
    while (head) {
        CLL* tmp = head->next;
        delete head;
        head = tmp;
    }
}

void Solution::create(std::vector<int>& arr)
{
    CLL* head = nullptr;
    CLL* mover = nullptr;
    for (int x : arr)
    {
        CLL* node = new CLL(x);
        if (head == nullptr)
        {
            head = node;
            mover = head;
        }
        else
        {
            mover->next = node;
            mover = mover->next;
        }
    }
    mover->next=head;
    heads.push_back(head);
}

// Insert value y at position pos (1-based) in list at heads[index]
void Solution::Insert(int y, int pos, int index)
{
    if (index < 0 || index >= static_cast<int>(heads.size())) return;
    CLL* &head = heads[index];

    if (pos <= 1 || head == nullptr)
    {
        CLL* node = new CLL(y);
        node->next = head;
        head = node;
        return;
    }

    CLL* mover = head;
    int i = 1;
    while (mover && i < pos - 1)
    {
        mover = mover->next;
        ++i;
    }
    if (!mover) return;

    CLL* node = new CLL(y);
    node->next = mover->next;
    mover->next = node;
}

void Solution::Delete(int pos, int index)
{
    if (index < 0 || index >= static_cast<int>(heads.size())) return;
    CLL* &head = heads[index];
    if (!head) return;

    if (pos <= 1)
    {
        CLL* tmp = head;
        head = head->next;
        delete tmp;
        return;
    }

    CLL* mover = head;
    int i = 1;
    while (mover->next && i < pos - 1)
    {
        mover = mover->next;
        ++i;
    }
    if (!mover->next) return;

    CLL* tmp = mover->next;
    mover->next = tmp->next;
    delete tmp;
}

void Solution::Sort(int index)
{
    if (index < 0 || index >= static_cast<int>(heads.size())) return;
    CLL* head = heads[index];
    if (!head || !head->next) return;

    // Simple bubble-like sort on node->x (in-place value swap)
    bool swapped;
    do {
        // cout<<"REACHED"<<endl;
        swapped = false;
        CLL* cur = head;
        do {
            // cout<<"reached"<<endl;
            if(cur->next==head)
            {
                break;
            }
            if (cur->x > cur->next->x) {
                std::swap(cur->x, cur->next->x);
                swapped = true;
            }
            cur = cur->next;
        } while (true);
    } while (swapped);
}

void Solution::Search(int num, int index) const
{
    if (index < 0 || index >= static_cast<int>(heads.size())) {
        std::cout << "Index out of range\n";
        return;
    }
    CLL* mover = heads[index];
    do
    {
        if (mover->x == num)
        {
            std::cout << "Element exists." << std::endl;
            return;
        }
        mover = mover->next;
    }
    while(mover!=heads[index]);
    cout << "Element does not exist." << std::endl;
}

void Solution::Merge(int index1, int index2)
{
    if (index1 < 0 || index1 >= static_cast<int>(heads.size())) return;
    if (index2 < 0 || index2 >= static_cast<int>(heads.size())) return;
    if (index1 == index2) return;

    CLL* &h1 = heads[index1];
    CLL* &h2 = heads[index2];

    CLL *mover_1=h1;
    CLL *mover_2=h2;

    bool b_1=true;
    bool b_2=true;

    while (true)
    {
        if(mover_1->next==h1 && b_1)
        {
            mover_1->next=h2;
            b_1=false;
        }
        if(mover_2->next==h2 && b_2)
        {
            mover_2->next=h1;
            b_2=false;
        }

        if(!(b_1 || b_2))
            break;

        mover_1=mover_1->next;
        mover_2=mover_2->next;
    }
    
}

void Solution::Display(int index) const
{
    if (index < 0 || index >= static_cast<int>(heads.size())) {
        cout << "Index out of range\n";
        return;
    }
    CLL* mover = heads[index];
    do
    {
        std::cout << mover->x << " ";
        mover = mover->next;
    }
    while(mover!=heads[index]);
    cout << endl;
}

} // namespace cll