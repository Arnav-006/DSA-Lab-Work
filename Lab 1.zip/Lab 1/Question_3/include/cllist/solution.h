#ifndef DLLIST_SOLUTION_H
#define DLLIST_SOLUTION_H

#include "cllist/cll.h"
#include <vector>

using namespace std;

namespace cll
{
    class Solution
    {
    private:
        vector <CLL*> heads;
        void free_list(CLL *head) noexcept;

    public:
        Solution() = default;
        ~Solution();

        void create(vector <int>&);
        void Insert(int y, int pos, int index = 0);
        void Delete(int pos, int index = 0);
        void Sort(int index = 0);
        void Search(int num, int index = 0) const;
        void Merge(int index1 = 0, int index2 = 1);
        void Display(int index = 0) const;

    };

}

#endif