#ifndef CLLIST_CLL_H
#define CLLIST_CLL_H

namespace cll
{
    struct CLL
    {
        int x;
        CLL *next;

        explicit CLL(int k): x(k), next(nullptr) {};
    };
} // namespace cll


#endif