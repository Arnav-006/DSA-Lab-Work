#ifndef DCLLIST_DLL_H
#define DCLLIST_DLL_H

#include <cstddef>

namespace dcllist {

struct DCLL
{
    int x;
    DCLL* next;
    DCLL* previous;

    explicit DCLL(int n) : x(n), next(nullptr), previous(nullptr) {}     
    //keyword prevents implicit type conversions, helps avoid subtle bugs
};

} 

#endif 