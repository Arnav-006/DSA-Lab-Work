#ifndef DCLLIST_SOLUTION_H
#define DCLLIST_SOLUTION_H

#include "dcllist/dcll.h"
#include <vector>

using namespace std;

namespace dcllist {

class Solution
{
private:
    vector<DCLL*> heads;

    void free_list(DCLL* head) noexcept; 

public:
    Solution() = default;
    ~Solution(); 

    void create(vector <int>&);
    void display(int);
    void insert(int, int, int);
    void _delete(int, int);
    void _search(int, int) const;
    void _sort(int);
    void _merge(int, int);
};

} 

#endif 
