#include <iostream>
#include <vector>
#include "dcllist/solution.h"
#include "dcllist/dcll.h"

using namespace std;

namespace dcllist
{

    Solution::~Solution()
    {
        for (DCLL *h : heads)
        {
            free_list(h);
        }
        heads.clear();
    }

    void Solution::free_list(DCLL *head) noexcept
    {
        while (head)
        {
            DCLL *tmp = head->next;
            delete head;
            head = tmp;
        }
    }

    void Solution::create(vector<int> &arr)
    {
        DCLL *head = nullptr, *mover = nullptr;
        for (int x : arr)
        {
            DCLL *node = new DCLL(x);
            if (head == nullptr)
            {
                head = node;
                mover = node;
            }
            else
            {
                mover->next = node;
                mover->next->previous = mover;
                mover = mover->next;
            }
        }
        mover->next = head;
        head->previous = mover;
        heads.push_back(head);
    }

    void Solution::display(int index)
    {
        DCLL *mover = heads[index];
        do
        {
            cout << mover->x << " ";
            mover = mover->next;
        } while (mover != heads[index]);
        cout << endl;
    }

    void Solution::insert(int y, int pos, int index)
    {
        if (index < 0 || index >= static_cast<int>(heads.size()))
            return;

        DCLL *&head = heads[index];

        if (pos == 1 || head == nullptr)
        {
            DCLL *node = new DCLL(y);
            node->next = head;
            head->previous = node;
            head = node;
            return;
        }

        DCLL *mover = head;
        int i = 1;
        while (i < pos - 1)
        {
            mover = mover->next;
            ++i;
            if (mover == head)
                break;
        }
        if (!mover)
            return;

        DCLL *node = new DCLL(y);
        node->next = mover->next;
        mover->next = node;
        node->previous = mover;
    }

    void Solution::_delete(int pos, int index)
    {
        if (index < 0 || index >= static_cast<int>(heads.size()))
            return;

        DCLL *&head = heads[index];
        if (!head)
            return;

        if (pos <= 1)
        {
            DCLL *tmp = head;
            head = head->next;
            head->previous = nullptr;
            delete tmp;
            return;
        }

        DCLL *mover = head;
        int i = 1;
        while (i < pos - 1)
        {
            mover = mover->next;
            ++i;
            if (mover == head)
                break;
        }
        if (!mover->next)
            return;

        DCLL *tmp = mover->next;
        mover->next = tmp->next;
        tmp->next->previous = mover;
        delete tmp;
    }

    void Solution::_search(int num, int index=0) const
    {
        if (index < 0 || index >= static_cast<int>(heads.size()))
        {
            std::cout << "Index out of range\n";
            return;
        }
        DCLL *mover = heads[index];
        do
        {
            if (mover->x == num)
            {
                std::cout << "Element exists." << std::endl;
                return;
            }
            mover = mover->next;
        } while (mover != heads[index]);
        std::cout << "Element does not exist." << std::endl;
    }

    void Solution::_sort(int index)
    {
        if (index < 0 || index >= static_cast<int>(heads.size()))
            return;
        DCLL *head = heads[index];
        if (!head || !head->next)
            return;

        // Simple bubble-like sort on node->x (in-place value swap)
        bool swapped;
        do
        {
            swapped = false;
            DCLL *cur = head;
            while (true)
            {
                if (cur->next == head)
                {
                    break;
                }
                if (cur->x > cur->next->x)
                {
                    swap(cur->x, cur->next->x);
                    swapped = true;
                }
                cur = cur->next;
            }
        } while (swapped);
    }

    void Solution::_merge(int index1, int index2)
    {
        if (index1 < 0 || index1 >= static_cast<int>(heads.size()))
            return;
        if (index2 < 0 || index2 >= static_cast<int>(heads.size()))
            return;
        if (index1 == index2)
            return;

        DCLL *&h1 = heads[index1];
        DCLL *&h2 = heads[index2];

        DCLL *mover_1 = h1;
        DCLL *mover_2 = h2;

        bool b_1 = true;
        bool b_2 = true;

        while (true)
        {
            if (mover_1->next == h1 && b_1)
            {
                mover_1->next = h2;
                h2->previous = mover_1;
                b_1 = false;
            }
            if (mover_2->next == h2 && b_2)
            {
                mover_2->next = h1;
                h1->previous = mover_2;
                b_2 = false;
            }

            if (!(b_1 || b_2))
                break;

            mover_1 = mover_1->next;
            mover_2 = mover_2->next;
        }
    }

} // namespace llist
