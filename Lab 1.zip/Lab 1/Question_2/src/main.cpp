#include "dllist/solution.h"
#include <iostream>
#include <vector>

using namespace std;

int main()
{
    vector<int> arr1={1,2,3,4,5,6,7};
    vector<int> arr2={8,9,10,11,12,13,14};


    llist :: Solution sol;

    sol.create(arr1);
    sol.display(0);

    cout<<endl;

    sol.create(arr2);
    sol.display(1);

    cout<<endl;

    sol.insert(15,4,0);
    sol.display(0);

    cout<<endl;

    sol.insert(16,7,1);
    sol.display(1);

    cout<<endl;

    sol._delete(1,0);
    sol.display(0);

    cout<<endl;

    sol._sort(0);
    sol.display(0);

    cout<<endl;

    sol._merge(0,1);
    sol.display(0);

    return 0;
}