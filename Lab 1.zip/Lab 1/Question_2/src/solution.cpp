#include <iostream>
#include <vector>
#include "dllist/solution.h"
#include "dllist/dll.h"

using namespace std;

namespace llist
{

    Solution::~Solution()
    {
        for (DLL *h : heads)
        {
            free_list(h);
        }
        heads.clear();
    }

    void Solution::free_list(DLL *head) noexcept
    {
        while (head)
        {
            DLL *tmp = head->next;
            delete head;
            head = tmp;
        }
    }

    void Solution::create(vector<int> &arr)
    {
        DLL *head = nullptr, *mover = nullptr;
        for (int x : arr)
        {
            DLL *node = new DLL(x);
            if (head == nullptr)
            {
                head = node;
                mover = node;
            }
            else
            {
                mover->next = node;
                mover->next->previous = mover;
                mover = mover->next;
            }
        }
        heads.push_back(head);
    }

    void Solution::display(int index)
    {
        DLL *mover = heads[index];
        while (mover)
        {
            cout << mover->x <<" ";
            mover = mover->next;
        }
        cout<<endl;
    }

    void Solution::insert(int y, int pos, int index)
    {
        if (index < 0 || index >= static_cast<int>(heads.size()))
            return;

        DLL *&head = heads[index];

        if (pos == 1 || head == nullptr)
        {
            DLL *node = new DLL(y);
            node->next = head;
            head->previous = node;
            head = node;
            return;
        }

        DLL *mover = head;
        int i = 1;
        while (mover && i < pos - 1)
        {
            mover = mover->next;
            ++i;
        }
        if (!mover)
            return;

        DLL *node = new DLL(y);
        node->next = mover->next;
        mover->next = node;
        node->previous = mover;
    }

    void Solution::_delete(int pos, int index)
    {
        if (index < 0 || index >= static_cast<int>(heads.size()))
            return;

        DLL *&head = heads[index];
        if (!head)
            return;

        if (pos <= 1)
        {
            DLL *tmp = head;
            head = head->next;
            head->previous = nullptr;
            delete tmp;
            return;
        }

        DLL *mover = head;
        int i = 1;
        while (mover->next && i < pos - 1)
        {
            mover = mover->next;
            ++i;
        }
        if (!mover->next)
            return;

        DLL *tmp = mover->next;
        mover->next = tmp->next;
        tmp->next->previous = mover;
        delete tmp;
    }

    void Solution::_search(int num, int index) const
    {
        if (index < 0 || index >= static_cast<int>(heads.size()))
        {
            std::cout << "Index out of range\n";
            return;
        }
        DLL *mover = heads[index];
        while (mover)
        {
            if (mover->x == num)
            {
                std::cout << "Element exists." << std::endl;
                return;
            }
            mover = mover->next;
        }
        std::cout << "Element does not exist." << std::endl;
    }

    void Solution::_sort(int index)
    {
        if (index < 0 || index >= static_cast<int>(heads.size()))
            return;
        DLL *head = heads[index];
        if (!head || !head->next)
            return;

        // Simple bubble-like sort on node->x (in-place value swap)
        bool swapped;
        do
        {
            swapped = false;
            DLL *cur = head;
            while (cur->next)
            {
                if (cur->x > cur->next->x)
                {
                    swap(cur->x, cur->next->x);
                    swapped = true;
                }
                cur = cur->next;
            }
        } while (swapped);
    }

    void Solution::_merge(int index1, int index2)
    {
        if (index1 < 0 || index1 >= static_cast<int>(heads.size()))
            return;
        if (index2 < 0 || index2 >= static_cast<int>(heads.size()))
            return;
        if (index1 == index2)
            return;

        DLL *&h1 = heads[index1];
        DLL *&h2 = heads[index2];

        if (!h1)
        {
            h1 = h2;
            h2 = nullptr;
            return;
        }

        DLL *mover = h1;
        while (mover->next)
            mover = mover->next;
        mover->next = h2;
        h2->previous = mover;
        h2 = nullptr;
    }

} // namespace llist
