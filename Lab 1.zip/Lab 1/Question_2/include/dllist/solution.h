#ifndef DLLIST_SOLUTION_H
#define DLLIST_SOLUTION_H

#include "dllist/dll.h"
#include <vector>

using namespace std;

namespace llist {

class Solution
{
private:
    vector<DLL*> heads;

    void free_list(DLL* head) noexcept; 

public:
    Solution() = default;
    ~Solution(); 

    void create(vector <int>&);
    void display(int);
    void insert(int, int, int);
    void _delete(int, int);
    void _search(int, int) const;
    void _sort(int);
    void _merge(int, int);
};

} 

#endif 
