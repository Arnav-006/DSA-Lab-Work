#ifndef DLLIST_DLL_H
#define DLLIST_DLL_H

#include <cstddef>

namespace llist {

struct DLL
{
    int x;
    DLL* next;
    DLL* previous;

    explicit DLL(int n) : x(n), next(nullptr), previous(nullptr) {}     
    //keyword prevents implicit type conversions, helps avoid subtle bugs
};

} 

#endif 