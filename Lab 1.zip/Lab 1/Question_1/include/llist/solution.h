#ifndef LLIST_SOLUTION_H
#define LLIST_SOLUTION_H

#include "llist/ll.h"
#include <vector>

namespace llist {

class Solution
{
private:
    // Each element of heads points to the head of one linked list
    std::vector<LL*> heads;

    // helper to free a single list
    void free_list(LL* head) noexcept;

public:
    Solution() = default;
    ~Solution(); // frees memory

    // operations (names kept similar to your original file)
    void create(std::vector<int>& arr);     // push a new list made from arr into 'heads'
    void Insert(int y, int pos, int index = 0);
    void Delete(int pos, int index = 0);
    void Sort(int index = 0);
    void Search(int num, int index = 0) const;
    void Reverse(int index = 0);
    void Merge(int index1 = 0, int index2 = 1);
    void Display(int index = 0) const;
};

} // namespace llist

#endif // LLIST_SOLUTION_H
