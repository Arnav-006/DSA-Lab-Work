#ifndef LLIST_LL_H
#define LLIST_LL_H

#include <cstddef>

namespace llist {

struct LL
{
    int x;
    LL* next;

    explicit LL(int n) : x(n), next(nullptr) {}     //prevents implicit type conversions, helps avoid subtle bugs
};

} 

#endif 
