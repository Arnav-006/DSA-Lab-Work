// Update the path below if "solution.h" is located elsewhere, e.g., "../llist/solution.h" or just "solution.h"
#include "llist/solution.h"
#include <vector>

int main()
{
    std::vector<int> arr1 = {1,2,3,4,5,6};
    std::vector<int> arr2 = {8,9,10,11,12,13};

    llist::Solution sol;

    sol.create(arr1);
    sol.Display();          // list 0: 1 2 3 4 5 6

    sol.Insert(7, 2);       // insert 7 at position 2 -> 1 7 2 3 4 5 6
    sol.Display();          // prints list 0

    sol.Delete(4);          // delete position 4 -> 1 7 2 4 5 6
    sol.Display();

    sol.Sort();             // sort list 0
    sol.Display();          // 1 2 4 5 6 7

    sol.create(arr2);       // adds list 1
    sol.Merge(0,1);         // concatenate list1 to list0
    sol.Display();          // displays merged list (index 0)

    sol.Search(4);

    return 0;
}
