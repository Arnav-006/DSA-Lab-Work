#include "llist/solution.h"
#include <iostream>
#include <algorithm>

using namespace std;

namespace llist {

Solution::~Solution()
{
    for (LL* h : heads) {
        free_list(h);
    }
    heads.clear();
}

void Solution::free_list(LL* head) noexcept
{
    while (head) {
        LL* tmp = head->next;
        delete head;
        head = tmp;
    }
}

void Solution::create(std::vector<int>& arr)
{
    LL* head = nullptr;
    LL* mover = nullptr;
    for (int x : arr)
    {
        LL* node = new LL(x);
        if (head == nullptr)
        {
            head = node;
            mover = head;
        }
        else
        {
            mover->next = node;
            mover = mover->next;
        }
    }
    heads.push_back(head);
}

// Insert value y at position pos (1-based) in list at heads[index]
void Solution::Insert(int y, int pos, int index)
{
    if (index < 0 || index >= static_cast<int>(heads.size())) return;
    LL* &head = heads[index];

    if (pos <= 1 || head == nullptr)
    {
        LL* node = new LL(y);
        node->next = head;
        head = node;
        return;
    }

    LL* mover = head;
    int i = 1;
    while (mover && i < pos - 1)
    {
        mover = mover->next;
        ++i;
    }
    if (!mover) return;

    LL* node = new LL(y);
    node->next = mover->next;
    mover->next = node;
}

void Solution::Delete(int pos, int index)
{
    if (index < 0 || index >= static_cast<int>(heads.size())) return;
    LL* &head = heads[index];
    if (!head) return;

    if (pos <= 1)
    {
        LL* tmp = head;
        head = head->next;
        delete tmp;
        return;
    }

    LL* mover = head;
    int i = 1;
    while (mover->next && i < pos - 1)
    {
        mover = mover->next;
        ++i;
    }
    if (!mover->next) return;

    LL* tmp = mover->next;
    mover->next = tmp->next;
    delete tmp;
}

void Solution::Sort(int index)
{
    if (index < 0 || index >= static_cast<int>(heads.size())) return;
    LL* head = heads[index];
    if (!head || !head->next) return;

    // Simple bubble-like sort on node->x (in-place value swap)
    bool swapped;
    do {
        swapped = false;
        LL* cur = head;
        while (cur->next) {
            if (cur->x > cur->next->x) {
                std::swap(cur->x, cur->next->x);
                swapped = true;
            }
            cur = cur->next;
        }
    } while (swapped);
}

void Solution::Search(int num, int index) const
{
    if (index < 0 || index >= static_cast<int>(heads.size())) {
        std::cout << "Index out of range\n";
        return;
    }
    LL* mover = heads[index];
    while (mover)
    {
        if (mover->x == num)
        {
            std::cout << "Element exists." << std::endl;
            return;
        }
        mover = mover->next;
    }
    std::cout << "Element does not exist." << std::endl;
}

void Solution::Reverse(int index)
{
    if (index < 0 || index >= static_cast<int>(heads.size())) return;
    LL* head = heads[index];
    if (!head || !head->next) return;

    LL* prev = nullptr;
    LL* cur = head;
    while (cur) {
        LL* nxt = cur->next;
        cur->next = prev;
        prev = cur;
        cur = nxt;
    }
    // prev is new head
    heads[index] = prev;
}

void Solution::Merge(int index1, int index2)
{
    if (index1 < 0 || index1 >= static_cast<int>(heads.size())) return;
    if (index2 < 0 || index2 >= static_cast<int>(heads.size())) return;
    if (index1 == index2) return;

    LL* &h1 = heads[index1];
    LL* &h2 = heads[index2];

    if (!h1) {
        h1 = h2;
        h2 = nullptr;
        return;
    }

    LL* mover = h1;
    while (mover->next) mover = mover->next;
    mover->next = h2;
    h2 = nullptr; // avoid double-use; ownership transferred
}

void Solution::Display(int index) const
{
    if (index < 0 || index >= static_cast<int>(heads.size())) {
        cout << "Index out of range\n";
        return;
    }
    LL* mover = heads[index];
    while (mover)
    {
        std::cout << mover->x << " ";
        mover = mover->next;
    }
    cout << endl;
}

} // namespace llist
